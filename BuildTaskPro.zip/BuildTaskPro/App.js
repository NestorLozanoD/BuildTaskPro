const express = require('express');
const app = express();
const port = process.env.PORT || 3000; // Puerto en el que se ejecutará el servidor
app.set('view engine', 'html');
app.use(express.static(__dirname + '/Views'));

//********************************************************************************** backend
// Definir la ruta para la página inicial
app.get('/', (req, res) => {
//    res.send('¡Bienvenido a BuildTaskPro!');
    res.sendFile(__dirname + '/views/index.html');
});

// Configurar middleware para manejar solicitudes POST
app.use(express.urlencoded({ extended: true }));

// Ruta para el formulario de inicio de sesión (GET)
app.get('/login', (req, res) => {
    res.sendFile(__dirname + '/views/Administrativo/index.html');
});

// Ruta para manejar el envío del formulario de inicio de sesión (POST)
app.post('/login', (req, res) => {
    const { username, password } = req.body;

    // Aquí podrías agregar la lógica de autenticación
    // Por ejemplo, puedes verificar el nombre de usuario y la contraseña
    if (username === 'nestorjld' && password === '1234567') {
        // Si la autenticación es exitosa, redirige a una página de éxito
        res.redirect('/showtareas.html?obj=nestorjld');
    } else {
        // Si la autenticación falla, redirige a una página de error o muestra un mensaje
        res.redirect('/login?error=¡Inicio+de+sesión+fallido!+Verifica+tus+credenciales');
        
    }
});

// Ruta para la página de éxito
app.get('/success', (req, res) => {
    res.send('¡Inicio de sesión exitoso!');
});

// Ruta para la página de error
app.get('/error', (req, res) => {
    res.send('¡Inicio de sesión fallido! Verifica tus credenciales.');
});

//**************************backend

// Iniciar el servidor
app.listen(port, () => {
    console.log(`Servidor BuildTaskPro iniciado en http://localhost:${port}`);
});

